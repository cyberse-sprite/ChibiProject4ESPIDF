#include "charactershadowsprite.h"
#include "core/assets/imageassets.h"

CharacterShadowSprite::CharacterShadowSprite(CharacterSprite *c, int x, int y)
{
    this->anchor=7;
    this->sprite=c;
    shadow=new AnimationSprite(IMG->get("shadow_0"),name+"_shadow");
    shadow->z=-99;
    shadow->x=0;
    shadow->y=2;
    shadow->anchor=7;
    pushChild(shadow);
    pushChild(this->sprite);
    this->x=x;
    this->y=y;
    addTricker("FreshPart",[this](){
        sprite->FreshParts();
        return "";
    });
}
