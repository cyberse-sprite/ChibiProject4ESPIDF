#include "core/assets/imageassets.h"
#include "inf/file.h"
#include <core/utils/textutils.h>

Image* ImageAssets::load(std::string name)
{
    std::string target="image/"+name;
    File file;
    if(!file.open(target,"r"))return nullptr;
    int i=0;
    while(!file.end()){
        Image image;
        image.x=file.readuint16_t();
        image.y=file.readuint16_t();
        image.w=file.readuint16_t();
        image.h=file.readuint16_t();
        image.dw=file.readuint16_t();
        image.dh=file.readuint16_t();
        image.type=file.readuint16_t();
        int size=image.dw*image.dh;
        image.data=new uint16_t[size];
        for(int i=0;i<size;i++){
            image.data[i]=file.readuint16_t();
        }
        image.alpha=new uint8_t[size];
        for(int i=0;i<size;i++){
            image.alpha[i]=file.readuint8_t();
        }
        if(file.end()){
            image.next=false;
        }
        if(i==0&&file.end()){
            items.insert(std::make_pair(name,image));
        }else{
            std::string res=name+"_"+std::to_string(i);
            image.name=res;
            items.insert(std::make_pair(res,image));
        }
        i++;
    }
    file.close();
    if(i>1)name=name+"_"+std::to_string(0);
    auto res=&items.at(name);
    return res;
}
