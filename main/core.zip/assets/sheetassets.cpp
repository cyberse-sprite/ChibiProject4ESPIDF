#include "sheetassets.h"
#include "inf/file.h"
#include "core/utils/textutils.h"

Sheet* SheetAssets::load(std::string name)
{
    Sheet s;
    File file;
    file.open("sheet/"+name,"r");
    while(!file.end()){
        std::vector<std::string> items=TextUtils::split(file.readLine(),',');
        if(items.size()<4)continue;
        s.frames.push_back(Frame{stoi(items[0]),stoi(items[1]),stoi(items[2]),stoi(items[3])});
    }
    file.close();
    items.insert(std::make_pair(name,s));
    return &items.at(name);
}
