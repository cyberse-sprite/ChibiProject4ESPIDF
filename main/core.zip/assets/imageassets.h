#ifndef IMAGE_ASSETS_H
#define IMAGE_ASSETS_H

#include "core/data/image.h"
#include <string>
#include "core/assets/assets.h"

class ImageAssets:public Assets<Image>
{
public:
    Image* load(std::string name);
};

extern ImageAssets* IMG;

#endif // ASSETS_H
