#ifndef ASSETS_H
#define ASSETS_H
#include "inf/log.h"
#include <map>
#include <string>

template <typename T>
class Assets
{
protected:
    std::map<std::string,T> items;
public:
    T* get(std::string name){
        typename std::map<std::string,T>::iterator i=items.find(name);
        if(i!=items.end()){
            return &(i->second);
        }
        return load(name);
    }
    virtual T* load(std::string name)=0;
};

#endif // ASSETS_H
