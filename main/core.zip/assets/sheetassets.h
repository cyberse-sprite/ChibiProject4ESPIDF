#ifndef SHEETASSETS_H
#define SHEETASSETS_H

#include "core/assets/assets.h"
#include "core/sprite/animationsprite.h"

class SheetAssets : public Assets<Sheet>
{
public:
    Sheet* load(std::string name);
};

extern SheetAssets* SHEET;

#endif // SHEETASSETS_H
