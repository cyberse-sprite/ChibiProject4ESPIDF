#include "paintevent.h"

PaintEvent::PaintEvent(int x,int y) {
    this->x=x;
    this->y=y;
}
