#ifndef IMAGE_H
#define IMAGE_H

#include <cstdint>
#include <string>

uint8_t newAlpha(uint8_t a1, uint8_t a2);

uint16_t newColor(uint8_t c1, uint8_t a1, uint8_t c2, uint8_t a2);

class RGBA
{
    uint16_t color;
    uint8_t alpha;

public:
    RGBA(uint16_t pix, uint8_t = 255);
    RGBA(uint8_t r = 0, uint8_t g = 0, uint8_t b = 0, uint8_t a = 255);
    RGBA operator+(const RGBA &pix);
    const uint8_t getR() const;
    const uint8_t getG() const;
    const uint8_t getB() const;
    const uint8_t getA() const;
    const uint16_t getColor() const;
};

struct Image
{
    uint16_t x;
    uint16_t y;
    uint16_t w;
    uint16_t h;
    uint16_t dw;
    uint16_t dh;
    uint16_t type;
    uint16_t *data=nullptr;
    uint8_t *alpha=nullptr;
    std::string name;
    bool next=true;
};

#endif // IMAGE_H
