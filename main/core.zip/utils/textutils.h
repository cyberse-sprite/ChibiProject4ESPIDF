#ifndef TEXTUTILS_H
#define TEXTUTILS_H

#include <string>
#include <vector>
class TextUtils
{
public:
    static std::vector<std::string> split(std::string str,char split);
};

#endif // TEXTUTILS_H
