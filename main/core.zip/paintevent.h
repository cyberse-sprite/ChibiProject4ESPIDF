#ifndef PAINTEVENT_H
#define PAINTEVENT_H

class PaintEvent
{
public:
    PaintEvent(int x=0,int y=0);
    int x;
    int y;
};

#endif // PAINTEVENT_H
